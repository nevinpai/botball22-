#include "drive.h"
#include <kipr/botball.h>
#include <kipr/wombat.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <stdbool.h>


#define TOPHAT_MAIN analog(1)
#define ET analog(0)

#define CLAW 0 //servo
#define OPEN 0
#define CLOSED 1100

#define BELT 3 //motor
#define RED -3400
#define ORANGE -4000
#define YELLOW -4700
#define GREEN -5400
#define BLUE -5900
#define VERTICAL -900


#define FORK 2 //motor
#define LPRONG 280
#define RPRONG 450

bool runThreadR = false; 
bool runThreadL = false; 



//TODO get the rings on the fork
bool mtpa(int motor, int speed, int goal){
    while(gmpc(motor)<goal){
        mav(motor,speed);
        msleep(1);
        freeze(motor);
          }
    while(gmpc(motor)>goal){
        mav(motor,speed*-1);
        msleep(1);
        freeze(motor);
          }
    freeze(motor);
    return true;
}

bool rings(){
    int speed = 700;
    int speedx = 200;
   	
    
    set_servo_position(CLAW, OPEN);
    mtpa(BELT,speed,RED);
    mtpa(FORK,speedx, LPRONG);
    runThreadL = true;
    freeze(FORK);
    set_servo_position(CLAW, CLOSED);
    mtpa(BELT,speed,VERTICAL);
    freeze(FORK);
    set_servo_position(CLAW, OPEN);
    runThreadL = false;
    mtpa(BELT,speed,ORANGE);
    freeze(FORK);
    mtpa(FORK,speedx, RPRONG);
    runThreadR = true;
    freeze(FORK);
    set_servo_position(CLAW, CLOSED);
    freeze(FORK);
    mtpa(BELT,speed,VERTICAL);
    freeze(FORK);
    set_servo_position(CLAW, OPEN);
    runThreadR = false;
    freeze(FORK);
    mtpa(BELT,speed,YELLOW);
    freeze(FORK);
    mtpa(FORK,speedx, LPRONG);
    runThreadL = true;
    freeze(FORK);
    set_servo_position(CLAW, CLOSED);
    freeze(FORK);
    mtpa(BELT,speed,VERTICAL);
    freeze(FORK);
    set_servo_position(CLAW, OPEN);
    runThreadL = false;
    freeze(FORK);
    mtpa(BELT,speed,GREEN);
    mtpa(FORK,speedx, RPRONG);
    runThreadR = true;
    freeze(FORK);
    set_servo_position(CLAW, CLOSED);
    freeze(FORK);
    mtpa(BELT,speed,VERTICAL);
    freeze(FORK);
    set_servo_position(CLAW, OPEN);
    runThreadR = false;
    freeze(FORK);
    mtpa(BELT,speed,BLUE);
    freeze(FORK);
    mtpa(FORK,speedx, LPRONG);
    runThreadL = true;
    freeze(FORK);
    set_servo_position(CLAW, CLOSED);
    freeze(FORK);
    mtpa(BELT,speed,VERTICAL);
    freeze(FORK);
    set_servo_position(CLAW, OPEN);
    runThreadL = false;
    freeze(FORK);
    
    runThreadL = false;
    runThreadR = false;
    
    return true;
}

bool startWombat(){
    enable_servos();
    cmpc(BELT);
    cmpc(FORK);
    
    //calibrate_Tophat();
    //calc_dev();
    printf("ready");
    return true;
}

void square_up2(){
    backward(10);
}
void backUp(){
    mav(MOT_LEFT,-600);
    msleep(500);
    freeze(MOT_LEFT);
}
void goToRings(){
    backward(15);
     mtpa(BELT,700,RED);
     set_servo_position(CLAW, OPEN);
    forward(15);
    backUp();
    
}
void cleanUpRings(){
    
    
}
void holdForkR(){
    int motor = FORK;
    int pos = RPRONG;
    while(1){
    while(runThreadR){
        while(pos-gmpc(motor)>10){ 
            mav(motor, 350);
            msleep(50);
            freeze(motor);
        }
        while(gmpc(motor)-pos>10){
            mav(motor, -350);
            msleep(50);
            freeze(motor);
        }
    }
        msleep(100);
    }
    
}

void holdForkL(){
    int motor = FORK;
    int pos = LPRONG;
    while(1){
    while(runThreadL){
        while(pos-gmpc(motor)>20){ 
            mav(motor, 350);
            msleep(50);
            freeze(motor);
        }
        while(gmpc(motor)-pos>20){
            mav(motor, -350);
            msleep(50);
            freeze(motor);
        }
    }
        msleep(100);
    }
    
}


int main()
{
   
  	//startWombat();
    thread holdR = thread_create(holdForkR);
    thread_start(holdR);
    runThreadR = true;
    msleep(100000);
    /*
    thread holdL = thread_create(holdForkL);
    thread_start(holdL);
    goToRings();
    rings();
    */
    disable_servos();
    
    return 0;
}
